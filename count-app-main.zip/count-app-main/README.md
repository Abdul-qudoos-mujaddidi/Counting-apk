# count-app
this is simple counting android app 
